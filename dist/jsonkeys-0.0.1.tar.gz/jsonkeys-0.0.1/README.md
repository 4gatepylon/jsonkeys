# jsonkeys
Script just to have the ability to print the keys of a json in a tree to help understand big JSONs (also supports YAMLs and pickles so long as the underlying object turns into a dict).

WARNING: This is not actively supported.